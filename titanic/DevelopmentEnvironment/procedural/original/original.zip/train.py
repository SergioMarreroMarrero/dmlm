import preprocessing_functions as pf
import config

# ================================================
# TRAINING STEP - IMPORTANT TO PERPETUATE THE MODEL

# Load data


# divide data set



# get first letter from cabin variable



# impute categorical variables



# impute numerical variable



# Group rare labels



# encode categorical variables



# check all dummies were added



# train scaler and save



# scale train set



# train model and save



print('Finished training')