# ====   PATHS ===================

PATH_TO_DATASET = "titanic.csv"
OUTPUT_SCALER_PATH = 'scaler.pkl'
OUTPUT_MODEL_PATH = 'logistic_regression.pkl'


# ======= PARAMETERS ===============

# imputation parameters
IMPUTATION_DICT = 


# encoding parameters
FREQUENT_LABELS = 


DUMMY_VARIABLES = 


# ======= FEATURE GROUPS =============

TARGET = 'survived'

CATEGORICAL_VARS = 

NUMERICAL_TO_IMPUTE = 